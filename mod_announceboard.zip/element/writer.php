﻿<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

class JFormFieldWriter extends JFormField
{

	protected	$type = 'writer';
    	function getInput(){
        $user = JFactory::getUser();
        if(empty($this->value))
        $this->value=$user->name;

        	return '<input type="text" id="'.$this->id.'" name="'.$this->name.'"  value="'.$this->value.'" readonly>';

        }
 }