﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();

// Include the helper class

$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));
$selectboxs=$params->get('selectbox',array());
$defaultimage=$params->get('image');
$limittitle=$params->get('limittitle',0);
$itemstyle=$params->get('itemstyle');
$itemimgstyle=$params->get('itemimgstyle');
$titlestyle=$params->get('titlestyle');
$modalstyle=$params->get('modalstyle');
$modalimg=$params->get('modalimg');
$descstyle=$params->get('descstyle');
$datestyle=$params->get('datestyle');
$writerstyle=$params->get('writerstyle');
$width=$params->get('modalwidth','50%');
$height=$params->get('modalheight','auto'); 
// Display the template
require(JModuleHelper::getLayoutPath('mod_announceboard'));

?>