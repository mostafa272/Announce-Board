﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
 defined('_JEXEC') or die();
  $document = JFactory::getDocument();
$style=".annonce-item".$moduleclass_sfx."{
".$itemstyle."
}
.annonce-item".$moduleclass_sfx." img{
".$itemimgstyle."
}
.annonce-item".$moduleclass_sfx." a{
display:block;
}
a.annonce-title".$moduleclass_sfx." {
".$titlestyle."
}
.annonce-body".$moduleclass_sfx."{
".$modalstyle."
}
.annonce-body".$moduleclass_sfx." img {
".$modalimg."
}
.annonce-desc".$moduleclass_sfx."{
".$descstyle."
}
.annonce-date".$moduleclass_sfx."{
".$datestyle."
}
.annonce-writer".$moduleclass_sfx."{
".$writerstyle."
}";
$document->addStyleDeclaration($style);
$user = JFactory::getUser();
$groups=$user->getAuthorisedViewLevels();
 $modal_params = array();
 $k=0;
?>
<?php foreach ($selectboxs as $selectbox) :
    $access=0;
    $date="";
    $writer="";
    $modal_params['height'] = $height;
    $modal_params['width'] = $width;
	$modal_params['title'] = $selectbox->title;
    if(!empty($selectbox->createdate))
    $date='<div class="annonce-date'.$moduleclass_sfx.'">'.JText::_('MOD_ANNOUNCE_DATE_TEXT').': '. JHtml::_('date',$selectbox->createdate, JText::_('DATE_FORMAT_LC3')).'</div>';
    if($selectbox->show_writer=='1')
    $writer='<div class="annonce-writer'.$moduleclass_sfx.'">'.JText::_('MOD_ANNOUNCE_AUTHOR_TEXT').': '.$selectbox->writer.'</div>';
    if(empty($selectbox->image))
    $selectbox->image='modules/mod_announceboard/img/'.$defaultimage;
   $body ='<div class="annonce-body'.$moduleclass_sfx.'">'.$date.$writer.'<img src="'.$selectbox->image.'" alt="'.$selectbox->title.'" title="'.$selectbox->title.'" />
   <div class="annonce-desc'.$moduleclass_sfx.'">'.$selectbox->description.'</div></div>';

for($i=0;$i<count($groups);$i++) {
 if(($groups[$i]==$selectbox->access) && ($selectbox->filter==1))
 $access=1;
}
if(!empty($selectbox->users))
{
for($i=0;$i<count($selectbox->users);$i++){
if($selectbox->users[$i]==$user->id)
$access=1;
}
}
if($access==1)
{
echo '<div class="annonce-item'.$moduleclass_sfx.'"><a href="#annoncemodal-'.$k.'" data-toggle="modal" ><img src="'.$selectbox->image.'" alt="'.$selectbox->title.'" title="'.$selectbox->title.'" /></a><a href="#annoncemodal-'.$k.'" class="annonce-title'.$moduleclass_sfx.'" data-toggle="modal" >'.JHTML::_('string.truncate',$selectbox->title,$limittitle).'</a></div>';
 echo JHTML::_('bootstrap.renderModal','annoncemodal-'.$k,$modal_params, $body);
$k++;
}

 endforeach;
?>